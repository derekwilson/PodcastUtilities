﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using log4net;
using Palmmedia.ReportGenerator.Analysis;
using Palmmedia.ReportGenerator.Parser;

namespace Palmmedia.ReportGenerator.Reporting
{
    /// <summary>
    /// HTML report renderer.
    /// </summary>
    public class HtmlRenderer : RendererBase, IReportRenderer
    {
        #region HTML Snippets

        /// <summary>
        /// The head of each generated HTML file.
        /// </summary>
        private const string HtmlStart = @"<!DOCTYPE html PUBLIC ""-//W3C//DTD XHTML 1.0 Strict//EN"" ""http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"">
<html><head><title>{0} - Coverage Report</title>
<meta http-equiv=""content-type"" content=""text/html; charset=UTF-8"" />
<style type=""text/css"">
html {{font-family: sans-serif; margin: 20px; font-size: 0.9em; background-color: #f5f5f5;}}
h1 {{font-size: 1.2em; font-weight: bold; margin: 20px 0px 15px 0px; padding: 0px;}}
h2 {{font-size: 1.0em; font-weight: bold; margin: 10px 0px 15px 0px;padding: 0px;}}
th {{text-align: left;}}
a {{color: #cc0000; text-decoration: none;}}
a:hover {{color: #000000; text-decoration: none;}}
.container {{margin: auto; width: 960px; border: solid 1px #a7bac5; padding: 0px 20px 20px 20px; background-color: #ffffff;}}
.overview {{ border: solid 1px #a7bac5; border-collapse: collapse;}}
.overview th {{ border: solid 1px #a7bac5; border-collapse: collapse; padding: 2px 5px 2px 5px; background-color: #d2dbe1;}}
.overview td {{ border: solid 1px #a7bac5; border-collapse: collapse; padding: 2px 5px 2px 5px;}}
.coverage {{ border: solid 1px #a7bac5; border-collapse: collapse; font-size: 5px;}}
.coverage td {{ padding: 0px; }}
.right {{text-align: right; padding-right: 8px;}}
.light {{color: #888888;}}
.leftmargin {{ padding-left: 5px; }}
.green {{background-color: #00ff21;}}
.red {{background-color: #ff0000;}}
.gray {{background-color: #dcdcdc;}}
.footer {{font-size: 0.7em; text-align: center; margin-top: 35px;}}
</style>
</head><body><div class=""container"">";

        /// <summary>
        /// The donate button.
        /// </summary>
        private const string HtmlDontate = @"<br /><br /><form action=""https://www.paypal.com/cgi-bin/webscr"" method=""post"">
<div>
<input type=""hidden"" name=""cmd"" value=""_s-xclick"" />
<input type=""image"" src=""https://www.paypal.com/en_US/i/btn/x-click-but04.gif"" name=""submit"" style=""border: 0px;"" alt=""Donate"" />
<img alt="""" src=""https://www.paypal.com/de_DE/i/scr/pixel.gif"" width=""1"" height=""1"" />
<input type=""hidden"" name=""encrypted"" value=""-----BEGIN PKCS7-----MIIHXwYJKoZIhvcNAQcEoIIHUDCCB0wCAQExggEwMIIBLAIBADCBlDCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20CAQAwDQYJKoZIhvcNAQEBBQAEgYCcaS71bkhl/ZbKtFtJsyINkaAmllwWYCWG38bJthuCV8o+OD3Fdw4m7jGu/jYYLhQ2GxuFwUYcsqy+orvs90OC9+km8w5/Al1I+llvwXc5GK31GY0Xgtnp3b9vF7Is+p90gA+Ot43Jv6Ne8o64YVb7JHPJqHJwInFKYJHFTgXEVzELMAkGBSsOAwIaBQAwgdwGCSqGSIb3DQEHATAUBggqhkiG9w0DBwQI352P0EFFAR2AgbhMpDdN0NZ0MF3M3MrVR+aLjyulnp3G924w3PEqvZZLWBhFCaC3tDO2rp+eWTIqxGPJAiv0SADDx88bvsn5W22lV5raYVTElsGB7sNclaoL1vVWBICJGZ9z8NQ1yL5qk/xmPiffIaszfcQNp6rLFUA2T36jU2ZmhUndBVV+n074/LQHmSYntkj32b1MXyLIBVyoJf79uYCJUU8m+YQEV01uZugPrn2jccqssLG1O2ZU4uA9W1i0ETeJoIIDhzCCA4MwggLsoAMCAQICAQAwDQYJKoZIhvcNAQEFBQAwgY4xCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJDQTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEUMBIGA1UEChMLUGF5UGFsIEluYy4xEzARBgNVBAsUCmxpdmVfY2VydHMxETAPBgNVBAMUCGxpdmVfYXBpMRwwGgYJKoZIhvcNAQkBFg1yZUBwYXlwYWwuY29tMB4XDTA0MDIxMzEwMTMxNVoXDTM1MDIxMzEwMTMxNVowgY4xCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJDQTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEUMBIGA1UEChMLUGF5UGFsIEluYy4xEzARBgNVBAsUCmxpdmVfY2VydHMxETAPBgNVBAMUCGxpdmVfYXBpMRwwGgYJKoZIhvcNAQkBFg1yZUBwYXlwYWwuY29tMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDBR07d/ETMS1ycjtkpkvjXZe9k+6CieLuLsPumsJ7QC1odNz3sJiCbs2wC0nLE0uLGaEtXynIgRqIddYCHx88pb5HTXv4SZeuv0Rqq4+axW9PLAAATU8w04qqjaSXgbGLP3NmohqM6bV9kZZwZLR/klDaQGo1u9uDb9lr4Yn+rBQIDAQABo4HuMIHrMB0GA1UdDgQWBBSWn3y7xm8XvVk/UtcKG+wQ1mSUazCBuwYDVR0jBIGzMIGwgBSWn3y7xm8XvVk/UtcKG+wQ1mSUa6GBlKSBkTCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb22CAQAwDAYDVR0TBAUwAwEB/zANBgkqhkiG9w0BAQUFAAOBgQCBXzpWmoBa5e9fo6ujionW1hUhPkOBakTr3YCDjbYfvJEiv/2P+IobhOGJr85+XHhN0v4gUkEDI8r2/rNk1m0GA8HKddvTjyGw/XqXa+LSTlDYkqI8OwR8GEYj4efEtcRpRYBxV8KxAW93YDWzFGvruKnnLbDAF6VR5w/cCMn5hzGCAZowggGWAgEBMIGUMIGOMQswCQYDVQQGEwJVUzELMAkGA1UECBMCQ0ExFjAUBgNVBAcTDU1vdW50YWluIFZpZXcxFDASBgNVBAoTC1BheVBhbCBJbmMuMRMwEQYDVQQLFApsaXZlX2NlcnRzMREwDwYDVQQDFAhsaXZlX2FwaTEcMBoGCSqGSIb3DQEJARYNcmVAcGF5cGFsLmNvbQIBADAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMDcxMTIxMDk0NjE2WjAjBgkqhkiG9w0BCQQxFgQUYQtVYpKi1+nk80CzJbbP24TGznYwDQYJKoZIhvcNAQEBBQAEgYBLv2ervSirWglsyBuSyZkuXbx0KsPauZzAB9xwUGta8fj1UinK0lZE66cSIA0TbRbpC3vBkJH8JUYFTY+Z3ZBRT3ShriYGfGBhMXxpASnfJDwxDr749VQ6X2exlPibG4vKk2PdeqqIWdAnmhLpvuj+thwZVCWfev6gFVuY07LMWg==-----END PKCS7-----"" />
</div>
</form>";

        /// <summary>
        /// The end of each generated HTML file.
        /// </summary>
        private const string HtmlEnd = "</div></body></html>";

        #endregion

        /// <summary>
        /// The logger.
        /// </summary>
        private static readonly ILog logger = LogManager.GetLogger(typeof(HtmlRenderer));

        /// <summary>
        /// The report builder.
        /// </summary>
        private StringBuilder reportBuilder;

        /// <summary>
        /// Begins the summary report.
        /// </summary>
        /// <param name="title">The title.</param>
        public void BeginSummaryReport(string title)
        {
            this.reportBuilder = new StringBuilder();
            this.reportBuilder.AppendFormat(HtmlStart, WebUtility.HtmlEncode(title));
        }

        /// <summary>
        /// Begins the class report.
        /// </summary>
        /// <param name="className">Name of the class.</param>
        public void BeginClassReport(string className)
        {
            this.reportBuilder = new StringBuilder();
            this.reportBuilder.AppendFormat(HtmlStart, WebUtility.HtmlEncode(className));
        }

        /// <summary>
        /// Adds a header to the report.
        /// </summary>
        /// <param name="text">The text.</param>
        public void Header(string text)
        {
            this.reportBuilder.AppendFormat("<h1>{0}</h1>", WebUtility.HtmlEncode(text));
        }

        /// <summary>
        /// Adds a file of a class to a report.
        /// </summary>
        /// <param name="path">The path of the file.</param>
        public void File(string path)
        {
            this.reportBuilder.AppendFormat("<h2 id=\"{0}\">{0}</h2>", WebUtility.HtmlEncode(path));
        }

        /// <summary>
        /// Adds a paragraph to the report.
        /// </summary>
        /// <param name="text">The text.</param>
        public void Paragraph(string text)
        {
            this.reportBuilder.AppendFormat("<p>{0}</p>", WebUtility.HtmlEncode(text));
        }

        /// <summary>
        /// Adds a table with two columns to the report.
        /// </summary>
        public void BeginKeyValueTable()
        {
            this.reportBuilder.AppendLine("<table class=\"overview\">");
        }

        /// <summary>
        /// Adds a summary table to the report.
        /// </summary>
        public void BeginSummaryTable()
        {
            this.reportBuilder.AppendLine("<table class=\"overview\">");
        }

        /// <summary>
        /// Adds a metrics table to the report.
        /// </summary>
        /// <param name="headers">The headers.</param>
        public void BeginMetricsTable(IEnumerable<string> headers)
        {
            if (headers == null)
            {
                throw new ArgumentNullException("headers");
            }

            this.reportBuilder.AppendLine("<table class=\"overview\">");
            this.reportBuilder.AppendLine("<tr>");

            foreach (var header in headers)
            {
                this.reportBuilder.AppendFormat("<th>{0}</th>", WebUtility.HtmlEncode(header));
            }

            this.reportBuilder.AppendLine("</tr>");
        }

        /// <summary>
        /// Adds a file analysis table to the report.
        /// </summary>
        /// <param name="headers">The headers.</param>
        public void BeginLineAnalysisTable(IEnumerable<string> headers)
        {
            if (headers == null)
            {
                throw new ArgumentNullException("headers");
            }

            this.reportBuilder.AppendLine("<table>");
            this.reportBuilder.AppendLine("<tr>");

            foreach (var header in headers)
            {
                this.reportBuilder.AppendFormat("<th>{0}</th>", WebUtility.HtmlEncode(header));
            }

            this.reportBuilder.AppendLine("</tr>");
        }

        /// <summary>
        /// Adds a table row with two cells to the report.
        /// </summary>
        /// <param name="key">The text of the first column.</param>
        /// <param name="value">The text of the second column.</param>
        public void KeyValueRow(string key, string value)
        {
            this.reportBuilder.AppendFormat(
                "<tr><th>{0}</th><td>{1}</td></tr>",
                WebUtility.HtmlEncode(key),
                WebUtility.HtmlEncode(value));
        }

        /// <summary>
        /// Adds a table row with two cells to the report.
        /// </summary>
        /// <param name="key">The text of the first column.</param>
        /// <param name="files">The files.</param>
        public void KeyValueRow(string key, IEnumerable<string> files)
        {
            string value = string.Join("<br />", files.Select(v => string.Format(CultureInfo.InvariantCulture, "<a href=\"#{0}\">{0}</a>", WebUtility.HtmlEncode(v))));

            this.reportBuilder.AppendFormat(
                "<tr><th>{0}</th><td>{1}</td></tr>",
                WebUtility.HtmlEncode(key),
                value);
        }

        /// <summary>
        /// Adds the given metric values to the report.
        /// </summary>
        /// <param name="metric">The metric.</param>
        public void MetricsRow(MethodMetric metric)
        {
            if (metric == null)
            {
                throw new ArgumentNullException("metric");
            }

            this.reportBuilder.Append("<tr>");

            this.reportBuilder.AppendFormat("<td>{0}</td>", WebUtility.HtmlEncode(metric.Name));

            foreach (var metricValue in metric.Metrics.Select(m => m.Value))
            {
                this.reportBuilder.AppendFormat("<td>{0}</td>", metricValue);
            }

            this.reportBuilder.Append("</tr>");
        }

        /// <summary>
        /// Adds the coverage information of a single line of a file to the report.
        /// </summary>
        /// <param name="analysis">The line analysis.</param>
        public void LineAnalysis(LineAnalysis analysis)
        {
            if (analysis == null)
            {
                throw new ArgumentNullException("analysis");
            }

            string formattedLine = analysis.LineContent
                .Replace(((char)11).ToString(), "  ") // replace tab
                .Replace(((char)9).ToString(), "  "); // replace tab

            if (formattedLine.Length > 120)
            {
                formattedLine = formattedLine.Substring(0, 120);
            }

            formattedLine = WebUtility.HtmlEncode(formattedLine);
            formattedLine = formattedLine.Replace(" ", "&nbsp;");

            string lineVisitStatus = "gray";

            if (analysis.LineVisitStatus == LineVisitStatus.Covered)
            {
                lineVisitStatus = "green";
            }
            else if (analysis.LineVisitStatus == LineVisitStatus.NotCovered)
            {
                lineVisitStatus = "red";
            }

            this.reportBuilder.AppendLine("<tr>");

            this.reportBuilder.AppendFormat(
                CultureInfo.InvariantCulture,
                "<td class=\"{0}\">&nbsp;</td>",
                lineVisitStatus);
            this.reportBuilder.AppendFormat(
                CultureInfo.InvariantCulture,
                "<td class=\"leftmargin right\">{0}</td>",
                analysis.LineVisitStatus != LineVisitStatus.NotCoverable ? analysis.LineVisits.ToString(CultureInfo.InvariantCulture) : string.Empty);
            this.reportBuilder.AppendFormat(
                CultureInfo.InvariantCulture,
                "<td class=\"right\"><code>{0}</code></td>",
                analysis.LineNumber);
            this.reportBuilder.AppendFormat(
                CultureInfo.InvariantCulture,
                "<td{0}><code>{1}</code></td>",
                analysis.LineVisitStatus == LineVisitStatus.NotCoverable ? " class=\"light\"" : string.Empty,
                formattedLine);

            this.reportBuilder.AppendLine("</tr>");
        }

        /// <summary>
        /// Finishes the current table.
        /// </summary>
        public void FinishTable()
        {
            this.reportBuilder.AppendLine("</table>");
        }

        /// <summary>
        /// Adds the coverage information of an assembly to the report.
        /// </summary>
        /// <param name="assemblyName">Name of the assembly.</param>
        /// <param name="coverageQuota">The coverage quota.</param>
        public void SummaryAssembly(string assemblyName, decimal coverageQuota)
        {
            this.reportBuilder.AppendFormat(
                CultureInfo.InvariantCulture,
                "<tr><th>{0}</td><th>{1}%</th><td>{2}</td></tr>",
                WebUtility.HtmlEncode(assemblyName),
                coverageQuota,
                CreateCoverageTable(coverageQuota));
        }

        /// <summary>
        /// Adds the coverage information of a class to the report.
        /// </summary>
        /// <param name="assemblyName">Name of the assembly.</param>
        /// <param name="className">Name of the class.</param>
        /// <param name="coverageQuota">The coverage quota.</param>
        public void SummaryClass(string assemblyName, string className, decimal coverageQuota)
        {
            this.reportBuilder.AppendFormat(
                CultureInfo.InvariantCulture,
                "<tr><td><a href=\"{0}\">{1}</a></td><td>{2}%</td><td>{3}</td></tr>",
                WebUtility.HtmlEncode(ReplaceInvalidPathChars(assemblyName + "_" + className) + ".htm"),
                WebUtility.HtmlEncode(className),
                coverageQuota,
                CreateCoverageTable(coverageQuota));
        }

        /// <summary>
        /// Saves a summary report.
        /// </summary>
        /// <param name="targetDirectory">The target directory.</param>
        public void SaveSummaryReport(string targetDirectory)
        {
            this.SaveReport(targetDirectory, "index.htm");
        }

        /// <summary>
        /// Saves a class report.
        /// </summary>
        /// <param name="targetDirectory">The target directory.</param>
        /// <param name="assemblyName">Name of the assembly.</param>
        /// <param name="className">Name of the class.</param>
        public void SaveClassReport(string targetDirectory, string assemblyName, string className)
        {
            this.SaveReport(targetDirectory, ReplaceInvalidPathChars(assemblyName + "_" + className) + ".htm");
        }

        /// <summary>
        /// Builds a table showing the coverage quota with red and green bars.
        /// </summary>
        /// <param name="coverage">The coverage quota.</param>
        /// <returns>Table showing the coverage quota with red and green bars.</returns>
        private static string CreateCoverageTable(decimal coverage)
        {
            var stringBuilder = new StringBuilder();
            int covered = (int)Math.Round(coverage, 0);
            int uncovered = 100 - covered;

            if (covered == 100)
            {
                covered = 103;
            }

            if (uncovered == 100)
            {
                uncovered = 103;
            }

            stringBuilder.Append("<table class=\"coverage\"><tr>");
            if (covered > 0)
            {
                stringBuilder.Append("<td class=\"green\" style=\"width: " + covered + "px;\">&nbsp;</td>");
            }

            if (uncovered > 0)
            {
                stringBuilder.Append("<td class=\"red\" style=\"width: " + uncovered + "px;\">&nbsp;</td>");
            }

            stringBuilder.Append("</tr></table>");
            return stringBuilder.ToString();
        }

        /// <summary>
        /// Saves the report.
        /// </summary>
        /// <param name="targetDirectory">The target directory.</param>
        /// <param name="fileName">Name of the file.</param>
        private void SaveReport(string targetDirectory, string fileName)
        {
            this.FinishReport();

            string targetPath = Path.Combine(targetDirectory, fileName);

            try
            {
                System.IO.File.WriteAllText(targetPath, this.reportBuilder.ToString(), Encoding.UTF8);
            }
            catch (IOException ex)
            {
                logger.ErrorFormat("Report '{0}' could not be saved: {1}", targetPath, ex.Message);
            }

            this.reportBuilder.Clear();
            this.reportBuilder = null;
        }

        /// <summary>
        /// Finishes the report.
        /// </summary>
        private void FinishReport()
        {
            this.reportBuilder.AppendFormat(
                CultureInfo.InvariantCulture,
                "<div class=\"footer\">Generated by: {0} {1}<br />{2} - {3}<br /><a href=\"http://www.palmmedia.de\">www.palmmedia.de</a>{4}</div>",
                this.GetType().Assembly.GetName().Name,
                this.GetType().Assembly.GetName().Version,
                DateTime.Now.ToShortDateString(),
                DateTime.Now.ToLongTimeString(),
                HtmlDontate);

            this.reportBuilder.Append(HtmlEnd);
        }
    }
}
