﻿using System;

namespace Test
{
    partial class PartialClass
    {
        public void ExecutedMethod_1()
        {
            Console.WriteLine("Test");
        }

        public void UnExecutedMethod_1()
        {
            Console.WriteLine("Test");
        }
    }
}
